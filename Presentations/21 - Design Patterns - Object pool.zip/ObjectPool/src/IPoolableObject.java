
public interface IPoolableObject {

	void doSomething();
}


public interface IObjectFactory<T> {

	T createNew();
}

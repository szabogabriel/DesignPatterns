package controller;

import subject.Agency;
import ui.AgencyFrame;

public class AgencyController {

	private final Agency agency;
	private final AgencyFrame agencyFrame;

	public AgencyController() {
		agency = new Agency();
		agencyFrame = new AgencyFrame(this);
	}

	public void submit(String news) {
		agency.notifyObservers(news);
	}

	public void openNewChannel() {
		new ChannelController(this).open();
	}

	public void open() {
		agencyFrame.setVisible(true);
	}

	public void close() {
		agencyFrame.dispose();
	}

	public Agency getAgency() {
		return agency;
	}
}

package subject;

import java.util.Objects;
import java.util.concurrent.ConcurrentLinkedQueue;

import observer.Observer;

public class Agency implements Subject {

	private final ConcurrentLinkedQueue<Observer> observers;

	public Agency() {
		observers = new ConcurrentLinkedQueue<>();
	}

	@Override
	public void registerObserver(Observer observer) {
		if (Objects.nonNull(observer) && !observers.contains(observer)) {
			observers.add(observer);
		}
	}

	@Override
	public void unregisterObserver(Observer observer) {
		if (Objects.nonNull(observer) && observers.contains(observer)) {
			observers.remove(observer);
		}
	}

	@Override
	public void notifyObservers(String news) {
		observers.stream().forEach(obs -> obs.update(news));
	}

	@Override
	public boolean isObserverRegistered(Observer observer) {
		return Objects.nonNull(observer) && observers.contains(observer);
	}
}

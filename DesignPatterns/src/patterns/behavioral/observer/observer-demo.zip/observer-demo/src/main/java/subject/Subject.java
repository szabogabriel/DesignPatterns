package subject;

import observer.Observer;

public interface Subject {

	void registerObserver(Observer observer);

	void unregisterObserver(Observer observer);

	void notifyObservers(String news);

	boolean isObserverRegistered(Observer observer);
}

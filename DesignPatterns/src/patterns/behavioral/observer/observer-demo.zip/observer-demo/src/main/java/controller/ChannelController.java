package controller;

import observer.Channel;
import ui.ChannelFrame;

public class ChannelController {

	private final Channel channel;
	private final ChannelFrame channelFrame;

	private AgencyController agencyController;

	public ChannelController(AgencyController agencyController) {
		this.agencyController = agencyController;
		channel = new Channel(this);
		channelFrame = new ChannelFrame(this);
	}

	public boolean isChannelSubscribed() {
		return agencyController.getAgency().isObserverRegistered(channel);
	}

	public void subscribeChannel() {
		agencyController.getAgency().registerObserver(channel);
	}

	public void unsubscribeChannel() {
		agencyController.getAgency().unregisterObserver(channel);
	}

	public void open() {
		channelFrame.setVisible(true);
	}

	public void close() {
		agencyController.getAgency().unregisterObserver(channel);
		channelFrame.dispose();
	}

	public Channel getChannel() {
		return channel;
	}

	public void updateChannelNews() {
		channelFrame.updateNews(channel.getNews());
	}
}

package ui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

import controller.AgencyController;
import core.MessageBundle;

@SuppressWarnings("squid:MaximumInheritanceDepth")
public class AgencyFrame extends JFrame {

	private static final long serialVersionUID = 1L;

	private static final Dimension DEFAULT_SIZE = new Dimension(600, 200);

	private transient AgencyController agencyController;

	private JTextField newsTextTf;

	public AgencyFrame(AgencyController mainController) {
		this.agencyController = mainController;
		initComponents();
	}

	private void initComponents() {
		setTitle("Observer Demo");
		setSize(DEFAULT_SIZE);
		setMinimumSize(DEFAULT_SIZE);
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				agencyController.close();
			}
		});

		JPanel mainPanel = new JPanel(new GridBagLayout());
		mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

		//
		// title panel
		//
		JPanel titlePanel = new JPanel();
		titlePanel.setMaximumSize(new Dimension(400, 50));

		JLabel titleLabel = new JLabel(MessageBundle.getMessage("frame.agency.title"));
		titleLabel.setFont(new Font("Arial", Font.BOLD, 30));
		titlePanel.add(titleLabel);
		mainPanel.add(titlePanel, BorderLayout.CENTER);

		//
		// submit panel
		//
		JPanel submitPanel = new JPanel();
		submitPanel.setMaximumSize(new Dimension(500, 50));

		JLabel newsTextLabel = new JLabel(MessageBundle.getMessage("label.news") + ":");
		newsTextLabel.setLabelFor(newsTextTf);
		submitPanel.add(newsTextLabel);

		newsTextTf = new JTextField(30);
		submitPanel.add(newsTextTf);

		JButton submitBtn = new JButton(MessageBundle.getMessage("button.submit.text"));
		submitBtn.addActionListener(actionEvent -> agencyController.submit(newsTextTf.getText()));
		submitPanel.add(submitBtn);
		mainPanel.add(submitPanel, BorderLayout.CENTER);

		//
		// open new channel panel
		//
		JPanel newChannelPanel = new JPanel();
		newChannelPanel.setMaximumSize(new Dimension(400, 50));

		JButton addChannelBtn = new JButton(MessageBundle.getMessage("button.openNewChannel.text"));
		addChannelBtn.addActionListener(actionEvent -> agencyController.openNewChannel());
		newChannelPanel.add(addChannelBtn);
		mainPanel.add(newChannelPanel, BorderLayout.CENTER);

		getContentPane().add(new JScrollPane(mainPanel));
	}
}

package observer;

import controller.ChannelController;

public class Channel implements Observer {

	private ChannelController channelController;
	private String news;

	public Channel(ChannelController channelController) {
		this.channelController = channelController;
	}

	@Override
	public void update(String news) {
		this.news = news;
		channelController.updateChannelNews();
	}

	public String getNews() {
		return news;
	}
}

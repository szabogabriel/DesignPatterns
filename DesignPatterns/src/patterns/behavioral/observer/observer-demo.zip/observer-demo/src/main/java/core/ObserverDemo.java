package core;

import controller.AgencyController;

public class ObserverDemo {

	public static void main(String[] args) {
		new AgencyController().open();
	}
}
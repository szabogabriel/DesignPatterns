package ui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.concurrent.atomic.AtomicInteger;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

import controller.ChannelController;
import core.MessageBundle;

@SuppressWarnings("squid:MaximumInheritanceDepth")
public class ChannelFrame extends JFrame {

	private static final long serialVersionUID = 1L;

	private static final AtomicInteger channelIdCount = new AtomicInteger();

	private static final Dimension DEFAULT_SIZE = new Dimension(600, 200);

	private transient ChannelController channelController;

	private JTextField newsTextTf;

	public ChannelFrame(ChannelController channelController) {
		this.channelController = channelController;
		initComponents();
	}

	private void initComponents() {
		setTitle(MessageBundle.getMessage("frame.channel.title", channelIdCount.incrementAndGet()));
		setSize(DEFAULT_SIZE);
		setMinimumSize(DEFAULT_SIZE);
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				channelController.close();
			}
		});

		JPanel mainPanel = new JPanel(new GridBagLayout());
		mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

		//
		// title panel
		//
		JPanel titlePanel = new JPanel();
		titlePanel.setMaximumSize(new Dimension(400, 50));

		JLabel titleLabel = new JLabel(getTitle());
		titleLabel.setFont(new Font("Arial", Font.BOLD, 30));
		titlePanel.add(titleLabel);
		mainPanel.add(titlePanel, BorderLayout.CENTER);

		//
		// news panel
		//
		JPanel newsPanel = new JPanel();
		newsPanel.setMaximumSize(new Dimension(500, 50));

		JLabel newsTextLabel = new JLabel(MessageBundle.getMessage("label.news") + ":");
		newsTextLabel.setLabelFor(newsTextTf);
		newsPanel.add(newsTextLabel);

		newsTextTf = new JTextField(30);
		newsTextTf.setEditable(false);
		newsPanel.add(newsTextTf);

		mainPanel.add(newsPanel, BorderLayout.CENTER);

		//
		// subscribe panel
		//
		JPanel subscribelPanel = new JPanel();
		subscribelPanel.setMaximumSize(new Dimension(400, 50));

		String subscribeMsg = MessageBundle.getMessage("button.subscribe.text");
		String unsubscribeMsg = MessageBundle.getMessage("button.unsubscribe.text");

		JButton subscribeBtn = new JButton(channelController.isChannelSubscribed() ? unsubscribeMsg : subscribeMsg);
		subscribeBtn.addActionListener(actionEvent -> {
			boolean isSubscribed = channelController.isChannelSubscribed();
			if (isSubscribed) {
				channelController.unsubscribeChannel();
			} else {
				channelController.subscribeChannel();
			}
			subscribeBtn.setText(channelController.isChannelSubscribed() ? unsubscribeMsg : subscribeMsg);
		});
		subscribelPanel.add(subscribeBtn);
		mainPanel.add(subscribelPanel, BorderLayout.CENTER);

		getContentPane().add(new JScrollPane(mainPanel));
	}

	public void updateNews(String news) {
		newsTextTf.setText(news);
	}
}

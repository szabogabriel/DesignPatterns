package core;

import java.security.InvalidParameterException;
import java.text.MessageFormat;
import java.util.Locale;
import java.util.ResourceBundle;

public final class MessageBundle {

	private static final String RESOURCE_FILE = "messages";

	private static final ResourceBundle resourceBundle = ResourceBundle.getBundle(RESOURCE_FILE, Locale.ENGLISH);

	private MessageBundle() {
		// hidden constructor
	}

	public static String getMessage(String key) {
		String value = resourceBundle.getString(key);
		if (value == null) {
			throw new InvalidParameterException(MessageFormat.format("Missing value for key {0}!", key));
		}
		return value;
	}

	public static String getMessage(String key, Object... params) {
		String pattern = getMessage(key);
		return MessageFormat.format(pattern, params);
	}

}
